package com.example.mobesp.mixin;

import com.example.mobesp.EspConfig;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1297.class)
public abstract class EntityMixin {
    @Inject(method = "getTeamColorValue", at = @At("HEAD"), cancellable = true)
    private void mobesp$customCategoryOutlineColor(CallbackInfoReturnable<Integer> cir) {
        class_1297 self = (class_1297) (Object) this;
        if (EspConfig.enabled && EspConfig.shaderOutline && EspConfig.shouldRender(self)) {
            cir.setReturnValue(EspConfig.classify(self).rgbHex);
        }
    }
}
