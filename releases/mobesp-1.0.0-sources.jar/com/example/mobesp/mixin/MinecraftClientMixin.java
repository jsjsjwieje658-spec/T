package com.example.mobesp.mixin;

import com.example.mobesp.EspConfig;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_310.class)
public abstract class MinecraftClientMixin {
    @Inject(method = "hasOutline", at = @At("HEAD"), cancellable = true)
    private void mobesp$forceEntityOutline(class_1297 entity, CallbackInfoReturnable<Boolean> cir) {
        if (EspConfig.enabled && EspConfig.shaderOutline && EspConfig.shouldRender(entity)) {
            cir.setReturnValue(true);
        }
    }
}
