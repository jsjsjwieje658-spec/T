package com.example.mobesp;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class MobEspClientMod implements ClientModInitializer {
    private static class_304 toggleEspKey;
    private static class_304 cycleFilterKey;
    private static class_304 toggleOutlineKey;
    private static class_304 toggleTracersKey;

    @Override
    public void onInitializeClient() {
        toggleEspKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.mobesp.toggle_esp",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_O,
                "category.mobesp.general"
        ));

        cycleFilterKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.mobesp.cycle_filter",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_P,
                "category.mobesp.general"
        ));

        toggleOutlineKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.mobesp.toggle_outline",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_I,
                "category.mobesp.general"
        ));

        toggleTracersKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.mobesp.toggle_tracers",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_U,
                "category.mobesp.general"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleEspKey.method_1436()) {
                EspConfig.enabled = !EspConfig.enabled;
                if (client.field_1724 != null) {
                    client.field_1724.method_7353(
                            class_2561.method_43470("§a[MobESP]§r Trạng thái: " + (EspConfig.enabled ? "§2BẬT" : "§cTẮT")),
                            true
                    );
                }
            }

            while (cycleFilterKey.method_1436()) {
                EspConfig.filterMode = EspConfig.filterMode.next();
                if (client.field_1724 != null) {
                    client.field_1724.method_7353(
                            class_2561.method_43470("§a[MobESP]§r Bộ lọc: §e" + EspConfig.filterMode.getDisplayName()),
                            true
                    );
                }
            }

            while (toggleOutlineKey.method_1436()) {
                EspConfig.shaderOutline = !EspConfig.shaderOutline;
                if (client.field_1724 != null) {
                    client.field_1724.method_7353(
                            class_2561.method_43470("§a[MobESP]§r Viền Xuyên Tường (Outline): " + (EspConfig.shaderOutline ? "§2BẬT" : "§cTẮT")),
                            true
                    );
                }
            }

            while (toggleTracersKey.method_1436()) {
                EspConfig.tracers = !EspConfig.tracers;
                if (client.field_1724 != null) {
                    client.field_1724.method_7353(
                            class_2561.method_43470("§a[MobESP]§r Đường chỉ hướng (Tracer): " + (EspConfig.tracers ? "§2BẬT" : "§cTẮT")),
                            true
                    );
                }
            }
        });

        WorldRenderEvents.AFTER_ENTITIES.register(EntityEspRenderer::renderWorld);
        HudRenderCallback.EVENT.register(EntityEspRenderer::renderHud);
    }
}
