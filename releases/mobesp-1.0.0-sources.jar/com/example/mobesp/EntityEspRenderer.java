package com.example.mobesp;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import org.joml.Matrix4f;

public final class EntityEspRenderer {
    private static int lastHostileCount = 0;
    private static int lastPassiveCount = 0;
    private static int lastPlayerCount = 0;
    private static int lastOtherCount = 0;

    private EntityEspRenderer() {
    }

    public static void renderWorld(WorldRenderContext context) {
        if (!EspConfig.enabled) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null) {
            return;
        }
        class_4587 matrices = context.matrixStack();
        class_4597 consumers = context.consumers();
        if (matrices == null || consumers == null) {
            return;
        }

        class_4184 camera = context.camera();
        class_243 cameraPos = camera.method_19326();
        float tickDelta = context.tickCounter().method_60637(false);
        class_4588 lineConsumer = consumers.getBuffer(class_1921.method_23594());

        // Điểm gốc đường chỉ hướng (Tracer) phía trước tầm nhìn camera
        class_243 lookVec = class_243.method_1030(camera.method_19329(), camera.method_19330()).method_1021(0.5);

        int hostile = 0;
        int passive = 0;
        int players = 0;
        int other = 0;

        for (class_1297 entity : client.field_1687.method_18112()) {
            if (!EspConfig.shouldRender(entity)) {
                continue;
            }
            EspConfig.EntityCategory category = EspConfig.classify(entity);
            switch (category) {
                case HOSTILE -> hostile++;
                case PASSIVE, WATER_AMBIENT -> passive++;
                case PLAYER -> players++;
                case NEUTRAL_OTHER -> other++;
            }

            double interpX = class_3532.method_16436(tickDelta, entity.field_6038, entity.method_23317()) - cameraPos.field_1352;
            double interpY = class_3532.method_16436(tickDelta, entity.field_5971, entity.method_23318()) - cameraPos.field_1351;
            double interpZ = class_3532.method_16436(tickDelta, entity.field_5989, entity.method_23321()) - cameraPos.field_1350;

            class_238 box = entity.method_5829()
                    .method_989(-entity.method_23317(), -entity.method_23318(), -entity.method_23321())
                    .method_989(interpX, interpY, interpZ)
                    .method_1014(0.03);

            class_761.method_22982(
                    matrices,
                    lineConsumer,
                    box,
                    category.r,
                    category.g,
                    category.b,
                    0.90f
            );

            if (EspConfig.tracers) {
                drawTracerLine(
                        matrices,
                        lineConsumer,
                        (float) lookVec.field_1352,
                        (float) lookVec.field_1351,
                        (float) lookVec.field_1350,
                        (float) interpX,
                        (float) (interpY + entity.method_17682() * 0.5),
                        (float) interpZ,
                        category.r,
                        category.g,
                        category.b,
                        0.65f
                );
            }
        }

        lastHostileCount = hostile;
        lastPassiveCount = passive;
        lastPlayerCount = players;
        lastOtherCount = other;
    }

    private static void drawTracerLine(
            class_4587 matrices,
            class_4588 consumer,
            float x1, float y1, float z1,
            float x2, float y2, float z2,
            float r, float g, float b, float a
    ) {
        class_4587.class_4665 entry = matrices.method_23760();
        Matrix4f posMatrix = entry.method_23761();
        float dx = x2 - x1;
        float dy = y2 - y1;
        float dz = z2 - z1;
        float len = class_3532.method_15355(dx * dx + dy * dy + dz * dz);
        if (len > 1.0e-4f) {
            dx /= len;
            dy /= len;
            dz /= len;
        } else {
            dx = 0.0f;
            dy = 1.0f;
            dz = 0.0f;
        }
        consumer.method_22918(posMatrix, x1, y1, z1).method_22915(r, g, b, a).method_60831(entry, dx, dy, dz);
        consumer.method_22918(posMatrix, x2, y2, z2).method_22915(r, g, b, a).method_60831(entry, dx, dy, dz);
    }

    public static void renderHud(class_332 drawContext, class_9779 tickCounter) {
        if (!EspConfig.enabled) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1690.field_1842) {
            return;
        }
        class_327 tr = client.field_1772;
        String statusLine = String.format(
                "[MobESP 1.21] ON | Lọc: %s | Outline: %s | Tracer: %s",
                EspConfig.filterMode.getDisplayName(),
                EspConfig.shaderOutline ? "ON" : "OFF",
                EspConfig.tracers ? "ON" : "OFF"
        );
        String countLine = String.format(
                "Quái: %d | Thú: %d | Người chơi: %d | Khác: %d",
                lastHostileCount, lastPassiveCount, lastPlayerCount, lastOtherCount
        );
        drawContext.method_27535(tr, class_2561.method_43470(statusLine), 6, 6, 0x55FF55);
        drawContext.method_27535(tr, class_2561.method_43470(countLine), 6, 17, 0xFFFFFF);
    }
}
